<?php

namespace Modules\OutsourceManufacturing\Http\Controllers;

use App\Transaction;
use App\Utils\ModuleUtil;
use DB;
use Illuminate\Routing\Controller;
use Menu;

class DataController extends Controller
{

    public function superadmin_package()
    {
        return [
            [
                'name' => 'outsource_manufacturing_module',
                'label' => __('outsourcemanufacturing::lang.outsource_manufacturing_module'),
                'default' => false
            ]
        ];
    }

    public function user_permissions()
    {
//
    }

    public function modifyAdminMenu()
    {
        if (auth()->user()->can('superadmin')) {
            $is_mfg_enabled = true;
        } else {
            $business_id = session()->get('user.business_id');
            $module_util = new ModuleUtil();
            $is_mfg_enabled = (boolean)$module_util->hasThePermissionInSubscription($business_id, 'outsource_manufacturing_module', 'superadmin_package');
        }
        if ($is_mfg_enabled
//            && (auth()->user()->can('manufacturing.access_recipe') || auth()->user()->can('manufacturing.access_production'))
        ) {
            Menu::modify('admin-sidebar-menu', function ($menu) {
                $menu->dropdown(
                    'OSM',
                    function ($sub) {
//                        if (auth()->user()->can('manufacturing.access_recipe')) {
                            $sub->url(
                                url('outsourcemanufacturing/issuance'),
                                __('Stock Issuance'),
                                ['icon' => 'fa fa-arrow-right', 'active' => request()->segment(1) == 'outsourcemanufacturing' && in_array(request()->segment(2), ['issuance'])]
                            );
                            $sub->url(
                                url('outsourcemanufacturing/receiving'),
                                __('Stock Received'),
                                ['icon' => 'fa fa-arrow-left', 'active' => request()->segment(1) == 'outsourcemanufacturing' && in_array(request()->segment(2), [ 'receiving'])]
                            );
//                            $sub->url(
//                                url('outsourcemanufacturing/report'),
//                                __('Stock Report'),
//                                ['icon' => 'fa fa-arrow-left', 'active' => request()->segment(1) == 'outsourcemanufacturing' && in_array(request()->segment(2), [ 'report'])]
//                            );
//                        }
                    },
                    ['icon' => 'fa fas fa-puzzle-piece']
                )->order(22);
            });
        }
    }

}
