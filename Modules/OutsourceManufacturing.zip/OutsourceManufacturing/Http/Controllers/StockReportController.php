<?php

namespace Modules\OutsourceManufacturing\Http\Controllers;

use App\BusinessLocation;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;
use Modules\OutsourceManufacturing\Entities\OSMIssuancDetail;
use Modules\OutsourceManufacturing\Entities\OSMIssuance;
use Modules\OutsourceManufacturing\Entities\OSMIssuancOutput;
use Modules\OutsourceManufacturing\Entities\OSMReceiving;
use Modules\OutsourceManufacturing\Entities\OSMReceivingDetail;
use Yajra\DataTables\DataTables;

class StockReportController extends Controller
{
    protected $VIEW = '';
    protected $TITLE = '';
    protected $URL = '';

    public function __construct()
    {
        $this->VIEW = 'outsourcemanufacturing::stocks.report';
        $this->URL = url('outsourcemanufacturing/report');
        $this->TITLE = __('OSM Report');
        view()->share([
            'title' => $this->TITLE,
            'url' => $this->URL,
        ]);
    }

    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function index()
    {
        return view($this->VIEW . '.index', [
            'records' => OSMReceiving::orderByDesc('date_time')
                ->paginate(10)
        ]);
    }

    /**
     * Show the form for creating a new resource.
     * @return Response
     */

    public function create()
    {
        return view($this->VIEW . '.create');
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Response
     */
    public function store(Request $request)
    {
        $output = ['success' => 1,
            'msg' => __('lang_v1.added_success')
        ];
        $user = auth()->user();
        $data = $request->only('o_s_m_issuance_id', 'wastage', 'remarks');
        $data['date_time'] = $request->transaction_date;
        $data['business_id'] = $user->business_id;
        $record = OSMReceiving::create($data);
        foreach ($request->receivings ?: [] as $product) {
            if ($product['qty']) {
                $product_data = [
                    'o_s_m_issuance_output_id' => $product['o_s_m_issuance_output_id'],
                    'product_id' => $product['product_id'],
                    'quantity' => $product['qty'],
                    'o_s_m_receiving_id' => $record->id,
                ];
                OSMReceivingDetail::create($product_data);
            }
        }
        return redirect($this->URL)->with('status', $output);
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Response
     */
    public function show($id)
    {
        return view($this->VIEW . '.show', [
            'record' => OSMReceiving::find($id)
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Response
     */
    public function edit($id)
    {
        return view('outsourcemanufacturing::edit');
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Response
     */
    public function destroy($id)
    {
        $business_id = request()->session()->get('user.business_id');

//        if (!(auth()->user()->can('superadmin') || $this->moduleUtil->hasThePermissionInSubscription($business_id, 'manufacturing_module')) ) {
//            abort(403, 'Unauthorized action.');
//        }

        if (request()->ajax()) {
            try {

               $record = OSMReceiving::where('id', $id)
                    ->where('business_id', $business_id)
                    ->first();
               if ($record){
                   $this->deleteMetas($record->id);
                   $record->delete();
               }
                $output = [
                    'success' => true,
                    'msg' => __('lang_v1.deleted_success')
                ];

            } catch (\Exception $e) {
                \Log::emergency("File:" . $e->getFile() . "Line:" . $e->getLine() . "Message:" . $e->getMessage());
                $output['success'] = false;
                $output['msg'] = trans("messages.something_went_wrong");
            }
            return $output;
        }
        return abort(403, 'Unauthorized action.');
    }
    public function deleteMetas($id)
    {
        OSMReceivingDetail::where('o_s_m_receiving_id',$id)->delete();
    }
}
