<?php

namespace Modules\OutsourceManufacturing\Http\Controllers;

use App\BusinessLocation;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;
use Modules\OutsourceManufacturing\Entities\OSMIssuancDetail;
use Modules\OutsourceManufacturing\Entities\OSMIssuance;
use Modules\OutsourceManufacturing\Entities\OSMIssuancOutput;
use Yajra\DataTables\DataTables;

class StockIssuanceController extends Controller
{
    protected $VIEW = '';
    protected $TITLE = '';
    protected $URL = '';

    public function __construct()
    {
        $this->VIEW = 'outsourcemanufacturing::stocks.issuance';
        $this->URL = url('outsourcemanufacturing/issuance');
        $this->TITLE = __('outsourcemanufacturing::lang.stock_issuance_list');
        view()->share([
            'title' => $this->TITLE,
            'url' => $this->URL,
        ]);
    }

    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function getList(Request $request)
    {

        $user = auth()->user();
//        $length = $this->paginateLength($request->length);
        $records = OSMIssuance::orderByDesc('date_time')
            ->paginate(10);
        $results = [];
        $sn = 1;
        foreach ($records as $r) {
            $url = $this->URL;
//            $delete_url = $this->toString($url . '/' . $r->id);
//            $show_url = $this->toString($url . '/' . $r->id);
            $actions = '';
//            $actions .= "<a href='javascript:' onclick='openFullWindowLink($show_url)'  title='View Record' class='primary p-0' ><i class='ft-printer font-medium-3 mr-2'></i></a>   ";
//
//            if ($user->hasDirectPermission('update_sale_delivery'))
//                $actions .= "<a href='$url/$r->id/edit' title='Edit Record' class='success p-0' ><i class='ft-edit-2 font-medium-3 mr-2'></i></a>   ";
//
//            if ($user->hasDirectPermission('delete_sale_delivery'))
//                $actions .= "<a href='javascript:' title='Delete Record' class='danger p-0' onclick='deleteRecordAjax($delete_url)'><i class='ft-x font-medium-3 mr-2'></i></a>";

            array_push($results, [
                'sn' => $sn++,
                'date' => date('d-m-Y', strtotime($r->date_time)),
                'ref_no' => $r->ref_no,
                'contact' => $r->getContactName(),
                'wastage' => $r->wastage,
                'production_cost' => $r->production_cost,
                'actions' => $actions,
            ]);

        }
        return DataTables::of($results)
            ->rawColumns(['actions'])
            ->make(true);

    }

    public function index()
    {
        return view($this->VIEW . '.index', [
            'records' => OSMIssuance::orderByDesc('date_time')
                ->paginate(10)
        ]);
    }

    /**
     * Show the form for creating a new resource.
     * @return Response
     */

    public function create()
    {
        $user = auth()->user();
        $business_id = $user->business_id;
        return view($this->VIEW . '.create', [
            'business_locations' => BusinessLocation::forDropdown($business_id)
        ]);
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Response
     */
    public function store(Request $request)
    {
        $output = ['success' => 1,
            'msg' => __('lang_v1.added_success')
        ];
        $user = auth()->user();
        $data = $request->only('ref_no', 'contact_id', 'location_id', 'production_cost', 'wastage');
        $data['business_id'] = $user->business_id;
        $data['date_time'] = date('Y-m-d',strtotime($request->transaction_date));
        $record = OSMIssuance::create($data);
        if (!$record->ref_no) {
            $record->ref_no = $record->id;
            $record->save();
        }
        foreach ($request->products ?: [] as $product) {

            $product_data = [
                'product_id' => $product['product_id'],
                'quantity' => $product['quantity'],
                'unit_id' => $product['sub_unit_id'],
                'o_s_m_issuanc_id' => $record->id,
            ];

            if ($product['table2']) {
                OSMIssuancOutput::create($product_data);
            } else {
                OSMIssuancDetail::create($product_data);
            }

        }
        return redirect($this->URL)->with('status', $output);
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Response
     */
    public function show($id)
    {

        $record = OSMIssuance::find($id);
        if (request('only_issuance')) {
            $record = OSMIssuance::where('ref_no', $id)->first();
            return view($this->VIEW . '.receiving', [
                'record' => $record
            ]);
        }
        if (!$record) {
            abort(404);
        }
        return view($this->VIEW . '.show', [
            'record' => $record
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Response
     */
    public function edit($id)
    {
        return view('outsourcemanufacturing::edit');
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Response
     */
    public function destroy($id)
    {
        $business_id = request()->session()->get('user.business_id');

//        if (!(auth()->user()->can('superadmin') || $this->moduleUtil->hasThePermissionInSubscription($business_id, 'manufacturing_module')) ) {
//            abort(403, 'Unauthorized action.');
//        }

        if (request()->ajax()) {
            try {
                $record = OSMIssuance::where('id', $id)
                    ->where('business_id', $business_id)
                    ->first();
                if ($record) {
                    OSMIssuancOutput::where('o_s_m_issuanc_id', $record->id)->delete();
                    OSMIssuancDetail::where('o_s_m_issuanc_id', $record->id)->delete();
                }

                $record->delete();

                $output = [
                    'success' => true,
                    'msg' => __('lang_v1.deleted_success')
                ];
            } catch (\Exception $e) {
                \Log::emergency("File:" . $e->getFile() . "Line:" . $e->getLine() . "Message:" . $e->getMessage());
                $output['success'] = false;
                $output['msg'] = trans("messages.something_went_wrong");
            }
            return $output;
        }
        return abort(403, 'Unauthorized action.');
    }
}
