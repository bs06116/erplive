<?php

namespace Modules\OutsourceManufacturing\Entities;

use App\Product;
use Illuminate\Database\Eloquent\Model;

class OSMIssuancOutput extends Model
{
    protected $guarded = [];

    public function product()
    {
        return $this->belongsTo(Product::class,'product_id');
    }

    public function receivings()
    {
        return $this->hasMany(OSMReceivingDetail::class,'o_s_m_issuance_output_id','id');
    }


}
