<?php

namespace Modules\OutsourceManufacturing\Entities;

use App\Product;
use Illuminate\Database\Eloquent\Model;

class OSMReceivingDetail extends Model
{
    protected $guarded = [];

    public function product()
    {
        return $this->belongsTo(Product::class,'product_id');
    }

}
