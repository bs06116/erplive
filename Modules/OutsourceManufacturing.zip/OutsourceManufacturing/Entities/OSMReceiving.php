<?php

namespace Modules\OutsourceManufacturing\Entities;

use App\BusinessLocation;
use App\Contact;
use Illuminate\Database\Eloquent\Model;

class OSMReceiving extends Model
{
    protected $guarded = [];

    public function details()
    {
        return $this->hasMany(OSMReceivingDetail::class);
    }

    public function issuance()
    {
        return $this->belongsTo(OSMIssuance::class, 'o_s_m_issuance_id','id');
    }

    public function date()
    {
        return date('d-m-Y',strtotime($this->date_time));
    }

    public function getContactName()
    {
        return $this->contact ? $this->contact->name : '';
    }

    public function getTotalMeta()
    {
        return [
            'receiving' => $this->details->sum('quantity'),
        ];
    }

}
