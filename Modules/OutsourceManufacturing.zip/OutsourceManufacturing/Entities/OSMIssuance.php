<?php

namespace Modules\OutsourceManufacturing\Entities;

use App\BusinessLocation;
use App\Contact;
use Illuminate\Database\Eloquent\Model;

class OSMIssuance extends Model
{
    protected $guarded = [];

    public function issuance()
    {
        return $this->hasMany(OSMIssuancDetail::class, 'o_s_m_issuanc_id');
    }

    public function manufactured()
    {
        return $this->hasMany(OSMIssuancOutput::class, 'o_s_m_issuanc_id');
    }

    public function date()
    {
        return date('d-m-Y', strtotime($this->date_time));
    }

    public function contact()
    {
        return $this->belongsTo(Contact::class, 'contact_id');
    }

    public function location()
    {
        return $this->belongsTo(BusinessLocation::class, 'location_id');
    }

    public function getContactName()
    {
        return $this->contact ? $this->contact->name : '';
    }

    public function getTotalMeta()
    {
        $receiving = 0;
        $manufactured = $this->manufactured;
        foreach ($manufactured as $item) {
            $receiving += $item->receivings->sum('quantity');
        }

        return [
            'issuance' => $this->issuance->sum('quantity'),
            'manufactured' => $manufactured->sum('quantity'),
            'receiving' => $receiving,
        ];
    }

}
