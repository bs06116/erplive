<?php


Route::group(['middleware' => ['web', 'authh', 'SetSessionData', 'auth', 'language', 'timezone', 'AdminSidebarMenu'],
    'prefix' => 'outsourcemanufacturing'], function () {
    Route::get('/install', 'InstallController@index');
    Route::post('/install', 'InstallController@install');
    Route::get('/install/update', 'InstallController@update');
    Route::get('/install/uninstall', 'InstallController@uninstall');

    Route::get('/', 'OutsourceManufacturingController@index');
    Route::resource('issuance', 'StockIssuanceController');
    Route::resource('receiving', 'StockReceivingController');
    Route::resource('report', 'StockReportController');

});