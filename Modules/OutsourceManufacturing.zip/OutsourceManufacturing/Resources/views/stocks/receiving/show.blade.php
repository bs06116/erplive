@php
    $issuance_inv = $record->issuance;
@endphp
@extends('layouts.blank')
@section('title', $title)

@section('content')

    <div class="">
        <div class="row">
            <div class="col-sm-12 text-center">
                <h2>Stock Receiving</h2>
            </div>
        </div>
        <hr>
        <div class="row invoice-info">
            <div class="col-sm-4 invoice-col">
                @lang('Supplier'):
                <address>
                    <strong>{{ $issuance_inv->getContactName() }}</strong>
                </address>
            </div>

            <div class="col-sm-4 invoice-col">
                <b>@lang('purchase.ref_no'):</b> #{{ $issuance_inv->ref_no }}<br/>
                <b>@lang('messages.date'):</b> {{ $record->date() }}<br/>
            </div>
{{--            <div class="col-sm-4 invoice-col">--}}
{{--                <b>Wastage:</b> {{ $record->wastage }}<br/>--}}
{{--                <b>Cost:</b> {{ $record->prodcution_cost }}<br/>--}}
{{--            </div>--}}
        </div>

        <div class="row">
            <div class="col-sm-12 col-xs-12">
                <h3>Stock Receiving List</h3>
                <div class="table-responsive">
                    <table class="table table-condensed table-bordered">
                        <thead>
                        <tr >
                            <th>@lang('sale.product')</th>
                            <th>@lang('sale.qty')</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach( $record->details as $issuance )
                            <tr>
                                <td>
                                    {{ $issuance->product->name }}
                                </td>
                                <td>
                                    {{@format_quantity($issuance->quantity)}}
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                        <tfoot>
                        <tr>
                            <th>Total</th>
                            <th>
                                {{@format_quantity($record->details->sum('quantity'))}}
                            </th>
                        </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <button type="button" class="btn btn-primary no-print" aria-label="Print"
                onclick="window.print()"><i class="fa fa-print"></i> @lang( 'messages.print' )
        </button>
    </div>
@stop
@section('javascript')
@endsection
