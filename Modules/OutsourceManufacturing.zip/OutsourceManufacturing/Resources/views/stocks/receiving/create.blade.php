@extends('layouts.app')
@section('title', $title)

@section('content')
    <style>
        .v-center {
            display: none !important;
        }
    </style>
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>{{ $title}} </h1>
    </section>

    <!-- Main content -->
    <section class="content">
        {!! Form::open(['url' => $url, 'method' => 'post', 'files' => true ]) !!}
        <div class="box box-primary">
            <div class="box-body">
                <div class="row">
                    <div class="col-sm-3">
                        <div class="form-group">
                            {!! Form::label('transaction_date', __('lang_v1.date') . ':*') !!}
                            <div class="input-group">
						<span class="input-group-addon">
							<i class="fa fa-calendar"></i>
						</span>
                                {!! Form::text('transaction_date', @format_datetime('now'), ['class' => 'form-control', 'readonly', 'required']); !!}
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="form-group">
                            {!! Form::label('ref_no', __('purchase.ref_no').':') !!}
                            {!! Form::text('ref_no', null, ['class' => 'form-control']); !!}
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="form-group">
                            <br>
                            <button type="button" onclick="loadOSMIssueInvoice()" class="btn btn-success">Load Invoice</button>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.box-body -->
        </div>
        <div class="box box-solid">
            <div class="box-header">
                <h3 class="box-title">Invoice Details</h3>
            </div>
            <div class="box-body" id="inv_issuance_details">

            </div>
        </div> <!--box end-->

        @component('components.widget', ['class' => 'box-primary', 'title' => ''])

            <div class="row">
                <div class="col-md-2">
                    <div class="form-group">
                        {!! Form::label('wastage','Wastage'.':') !!}
                            {!! Form::number('wastage', '', ['class' => 'form-control input_number']); !!}
                    </div>
                </div>
{{--                <div class="col-md-2">--}}
{{--                    <div class="form-group">--}}
{{--                        {!! Form::label('production_cost', 'Pay') !!}--}}
{{--                            {!! Form::number('production_cost', '', ['class' => 'form-control input_number']); !!}--}}
{{--                    </div>--}}
{{--                </div>--}}
                <div class="col-md-10">
                    <div class="form-group">
                        {!! Form::label('remarks', 'Remarks') !!}
                            {!! Form::text('remarks', '', ['class' => 'form-control']); !!}
                    </div>
                </div>
            </div>
            <hr>
            <div class="row">
                <div class="col-md-12">
                    <button type="submit" class="btn btn-primary btn-lg pull-right">@lang('messages.save')</button>
                </div>
            </div>
        @endcomponent

        {!! Form::close() !!}
    </section>

@endsection

@section('javascript')
    <script src="{{ asset('js/osm.js?v=' . $asset_v) }}"></script>
    <script>
        $(document).ready(function () {
            //get suppliers
        })
        var ref_num=$('#ref_no')
        var inv_issuance_details=$('#inv_issuance_details')

        function loadOSMIssueInvoice(){
            if (ref_num.val()){
                $.ajax({
                    url:'{{url('outsourcemanufacturing/issuance/')}}/' + ref_num.val(),
                    data:{
                        only_issuance:'1'
                    },
                    success:function (e){
                        inv_issuance_details.html(e)
                    },
                    error:function (){
                        alert('not found ')
                    }
                })
            }else {
                alert('please write ref no')
            }
        }
    </script>
@endsection
