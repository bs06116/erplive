@extends('layouts.app')
@section('title', $title)

@section('content')

<!-- Content Header (Page header) -->
{{--<section class="content-header">--}}
{{--    <h1>{{$title}}</h1>--}}
{{--</section>--}}

<!-- Main content -->
<section class="content">
    @component('components.widget', ['class' => 'box-primary'])
        @slot('tool')
            <div class="box-tools">
                <a class="btn btn-block btn-primary" href="{{$url.'/create'}}">
                    <i class="fa fa-plus"></i> @lang( 'messages.add' )</a>
            </div>
        @endslot
        <div class="table-responsive">
            <table class="table table-bordered table-striped" id="my-table">
                 <thead>
                    <tr>
                        <th>@lang('messages.date')</th>
                        <th>@lang('purchase.ref_no')</th>
                        <th>@lang('purchase.location')</th>
                        <th>@lang('lang_v1.suppliers')</th>
                        <th>@lang('lang_v1.quantity')</th>
                        <th>@lang('messages.action')</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($records as $record)
                        <?php
                            $record_meta = $record->getTotalMeta();
                            $issuance_inv = $record->issuance;
                        ?>
                        <tr>
                            <td>{{$record->date()}}</td>
                            <td>{{$issuance_inv->ref_no}}</td>
                            <td>{{$issuance_inv->location->name}}</td>
                            <td>{{$issuance_inv->getContactName()}}</td>
                            <td>{{$record_meta['receiving']}}</td>
                            <td>
{{--                                <a href="{{$url.'/'.$record->id.'/edit'}}" class=" "><span class="fa fa-edit" ></span></a>--}}
                                <a href="javascript:" onclick="openFullWindowLink('{{$url.'/'.$record->id}}')" class="text-success "><span class="fa fa-print" ></span></a>
                                <a href="javascript:" data-href="{{$url.'/'.$record->id}}" class="text-danger delete_a_record"><span class="fa fa-trash" ></span></a>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
        {{$records->links()}}
    @endcomponent
</section>

@stop
@section('javascript')

@endsection
