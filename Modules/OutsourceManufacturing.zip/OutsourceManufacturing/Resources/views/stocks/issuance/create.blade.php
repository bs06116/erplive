@extends('layouts.app')
@section('title', $title)

@section('content')
    <style>
        .v-center {
            display: none !important;
        }
    </style>
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>{{ $title}} </h1>
    </section>

    <!-- Main content -->
    <section class="content">
        {!! Form::open(['url' => $url, 'method' => 'post', 'files' => true ]) !!}

        <div class="box box-primary">

            <div class="box-body">
                <div class="row">
                    <div class="col-sm-3">
                        <div class="form-group">
                            {!! Form::label('ref_no', __('purchase.ref_no').':') !!}
                            {!! Form::text('ref_no', null, ['class' => 'form-control']); !!}
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="form-group">
                            {!! Form::label('transaction_date', __('lang_v1.date') . ':*') !!}
                            <div class="input-group">
						<span class="input-group-addon">
							<i class="fa fa-calendar"></i>
						</span>
                                {!! Form::text('transaction_date', @format_datetime('now'), ['class' => 'form-control', 'readonly', 'required']); !!}
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="form-group">
                            {!! Form::label('supplier_id', __('purchase.supplier') . ':*') !!}
                            <div class="input-group">
						<span class="input-group-addon">
							<i class="fa fa-user"></i>
						</span>
                                {!! Form::select('contact_id', [], null, ['class' => 'form-control', 'placeholder' => __('messages.please_select'), 'required', 'id' => 'supplier_id']); !!}
                                {{--						<span class="input-group-btn">--}}
                                {{--							<button type="button" class="btn btn-default bg-white btn-flat add_new_supplier" data-name=""><i class="fa fa-plus-circle text-primary fa-lg"></i></button>--}}
                                {{--						</span>--}}
                            </div>
                        </div>
                    </div>
                    @if(count($business_locations) == 1)
                        @php
                            $default_location = current(array_keys($business_locations->toArray()))
                        @endphp
                    @else
                        @php $default_location = null; @endphp
                    @endif
                    <div class="col-sm-3">
                        <div class="form-group">
                            {!! Form::label('location_id', __('purchase.business_location').':*') !!}
                            @show_tooltip(__('tooltip.purchase_location'))
                            {!! Form::select('location_id', $business_locations, $default_location, ['class' => 'form-control select2', 'required']); !!}
                        </div>
                    </div>
                </div>

            </div>
            <!-- /.box-body -->
        </div>
        <div class="box box-solid">
            <div class="box-header">
                <h3 class="box-title">Stock Issuance List</h3>
            </div>
            <div class="box-body">
                <div class="row">
                    <div class="col-sm-8 col-sm-offset-2">
                        <div class="form-group">
                            <div class="input-group">
							<span class="input-group-addon">
								<i class="fa fa-search"></i>
							</span>
                                {!! Form::text('search_product', null, ['class' => 'form-control', 'id' => 'search_product', 'placeholder' => __('lang_v1.search_product')]); !!}
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row col-sm-12 pos_product_div" style="min-height: 0">
                    <!-- Keeps count of product rows -->
                    <input type="hidden" id="product_row_count"
                           value="0">
                    <div class="table-responsive">
                        <table class="table table-condensed table-bordered table-striped table-responsive"
                               id="pos_table">
                            <thead>
                            <tr>
                                <th class="text-center">
                                    @lang('sale.product')
                                </th>
                                <th class="text-center">
                                    @lang('sale.qty')
                                </th>
                                <th class="text-center"><i class="fa fa-close" aria-hidden="true"></i></th>
                            </tr>
                            </thead>
                            <tbody></tbody>
                        </table>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-condensed table-bordered table-striped">
                            <tr>
                                <td>
                                    <div class="pull-right">
                                        <b>@lang('sale.item'):</b>
                                        <span class="total_quantity">0</span>
                                    </div>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div> <!--box end-->
        <div class="box box-solid">
            <div class="box-header">
                <h3 class="box-title">Stock Production List</h3>
            </div>
            <div class="box-body">
                <div class="row">
                    <div class="col-sm-8 col-sm-offset-2">
                        <div class="form-group">
                            <div class="input-group">
							<span class="input-group-addon">
								<i class="fa fa-search"></i>
							</span>
                                {!! Form::text('search_product', null, ['class' => 'form-control', 'id' => 'search_product2', 'placeholder' => __('lang_v1.search_product')]); !!}
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row col-sm-12 pos_product_div" style="min-height: 0">
                    <!-- Keeps count of product rows -->
                    <div class="table-responsive">
                        <table class="table table-condensed table-bordered table-striped table-responsive"
                               id="pos_table2">
                            <thead>
                            <tr>
                                <th class="text-center">
                                    @lang('sale.product')
                                </th>
                                <th class="text-center">
                                    @lang('sale.qty')
                                </th>
                                <th class="text-center"><i class="fa fa-close" aria-hidden="true"></i></th>
                            </tr>
                            </thead>
                            <tbody></tbody>
                        </table>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-condensed table-bordered table-striped">
                            <tr>
                                <td>
                                    <div class="pull-right">
                                        <b>@lang('sale.item'):</b>
                                        <span class="total_quantity2">0</span>
                                    </div>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div> <!--box end-->

        @component('components.widget', ['class' => 'box-primary', 'title' => ''])

            <div class="row">
                <div class="col-md-3">
                    <div class="form-group">
                        {!! Form::label('wastage','Wastage'.':') !!}
                        {!! Form::number('wastage', '', ['class' => 'form-control input_number']); !!}
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        {!! Form::label('production_cost', 'Production Cost:') !!}
                        {!! Form::text('production_cost', '', ['class' => 'form-control input_number']); !!}
                    </div>
                </div>
            </div>
            <hr>
            <div class="row">
                <div class="col-md-12">
                    <button type="submit" class="btn btn-primary btn-lg pull-right">@lang('messages.save')</button>
                </div>
            </div>
        @endcomponent

        {!! Form::close() !!}
    </section>

@endsection

@section('javascript')
    <script src="{{ asset('js/osm.js?v=' . $asset_v) }}"></script>
    <script>
        $(document).ready(function () {
            //get suppliers
            $('#supplier_id').select2({
                ajax: {
                    url: "{{url('purchases/get_suppliers')}}",
                    dataType: 'json',
                    delay: 250,
                    data: function (params) {
                        return {
                            q: params.term, // search term
                            page: params.page,
                        };
                    },
                    processResults: function (data) {
                        return {
                            results: data,
                        };
                    },
                },
                minimumInputLength: 1,
                escapeMarkup: function (m) {
                    return m;
                },
                templateResult: function (data) {
                    if (!data.id) {
                        return data.text;
                    }
                    var html = data.text + ' - ' + data.business_name + ' (' + data.contact_id + ')';
                    return html;
                },
                language: {
                    noResults: function () {
                        var name = $('#supplier_id')
                            .data('select2')
                            .dropdown.$search.val();
                        return (
                            '<button type="button" data-name="' +
                            name +
                            '" class="btn btn-link add_new_supplier"><i class="fa fa-plus-circle fa-lg" aria-hidden="true"></i>&nbsp; ' +
                            __translate('add_name_as_new_supplier', {name: name}) +
                            '</button>'
                        );
                    },
                },
            });
        })
    </script>
@endsection
