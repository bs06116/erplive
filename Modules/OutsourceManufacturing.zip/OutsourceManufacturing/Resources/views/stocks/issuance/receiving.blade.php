<input type="hidden" name="o_s_m_issuance_id" value="{{$record->id}}">
<div class="">
    {{--        <div class="row">--}}
    {{--            <div class="col-sm-12">--}}
    {{--                <p class="pull-right"><b>@lang('messages.date')--}}
    {{--                        :</b> {{ $record->date() }}</p>--}}
    {{--            </div>--}}
    {{--        </div>--}}
    <div class="row invoice-info">
        <div class="col-sm-4 invoice-col">
            Supplier:
            <address>
                <strong>{{ $record->getContactName() }}</strong>
            </address>
        </div>

        <div class="col-sm-4 invoice-col">
            <b>@lang('purchase.ref_no'):</b> #{{ $record->ref_no }}<br/>
            <b>@lang('messages.date'):</b> {{ $record->date() }}<br/>
        </div>
        <div class="col-sm-4 invoice-col">
            <b>Wastage:</b> {{ $record->wastage }}<br/>
            <b>Cost:</b> {{ $record->prodcution_cost }}<br/>
        </div>
    </div>

    <div class="row">
        <div class="col-sm-12 col-xs-12">
            <h3>Stock Issuance List</h3>
            <div class="table-responsive">
                <table class="table table-condensed table-bordered">
                    <thead>
                    <tr>
                        <th>@lang('sale.product')</th>
                        <th>@lang('sale.qty')</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach( $record->issuance as $issuance )
                        <tr>
                            <td>
                                {{ $issuance->product->name }}
                            </td>
                            <td>
                                {{@format_quantity($issuance->quantity)}}
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                    <tfoot>
                    <tr>
                        <th>Total</th>
                        <th>
                            {{@format_quantity($record->issuance->sum('quantity'))}}
                        </th>
                    </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-sm-12 col-xs-12">
            <h3>Stock Receiving List</h3>
            <div class="table-responsive">
                <table class="table table-condensed table-bordered">
                    <thead>
                    <tr>
                        <th>@lang('sale.product')</th>
                        <th>@lang('sale.qty')</th>
                        <th>Previous Receiving</th>
                        <th>Current Receiving</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach( $record->manufactured as $key => $issuance )
                        <tr>
                            <td>
                                {{ $issuance->product->name }}
                            </td>
                            <td>
                                {{@format_quantity($issuance->quantity)}}
                            </td>
                            <td>
                                {{@format_quantity($issuance->receivings->sum('quantity'))}}
                            </td>
                            <td>
                                <input type="hidden" name="receivings[{{$key}}][o_s_m_issuance_output_id]" value="{{$issuance->id}}">
                                <input type="hidden" name="receivings[{{$key}}][product_id]" value="{{$issuance->product_id}}">
                                <input name="receivings[{{$key}}][qty]" class="" type="number">
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                    <tfoot>
                    <tr>
                        <th>Total</th>
                        <th>
                            {{@format_quantity($record->manufactured->sum('quantity'))}}
                        </th>
                        <th></th>
                        <th></th>
                    </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
</div>

