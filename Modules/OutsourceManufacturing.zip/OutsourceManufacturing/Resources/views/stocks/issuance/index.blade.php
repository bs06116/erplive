@extends('layouts.app')
@section('title', $title)

@section('content')

<!-- Content Header (Page header) -->
{{--<section class="content-header">--}}
{{--    <h1>{{$title}}</h1>--}}
{{--</section>--}}

<!-- Main content -->
<section class="content">
    @component('components.widget', ['class' => 'box-primary'])
        @slot('tool')
            <div class="box-tools">
                <a class="btn btn-block btn-primary" href="{{$url.'/create'}}">
                    <i class="fa fa-plus"></i> @lang( 'messages.add' )</a>
            </div>
        @endslot
        <div class="table-responsive">
            <table class="table table-bordered table-striped" id="my-table">
                 <thead>
                    <tr>
                        <th>@lang('messages.date')</th>
                        <th>@lang('purchase.ref_no')</th>
                        <th>@lang('lang_v1.suppliers')</th>
                        <th>@lang('Output')</th>
                        <th>@lang('Received')</th>
                        <th>@lang('Remaining')</th>
                        <th>@lang('messages.action')</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                    $output=0;
                    $receiving=0;
                ?>
                    @foreach($records as $record)
                        <?php
                            $record_meta = $record->getTotalMeta();
                            $output+=$record_meta['manufactured'];
                            $receiving+=$record_meta['receiving'];
                        ?>
                        <tr>
                            <td>{{date('d-m-Y',strtotime($record->date_time))}}</td>
                            <td>{{$record->ref_no}}</td>
                            <td>{{$record->getContactName()}}</td>
                            <td>{{$record_meta['manufactured']}}</td>
                            <td>{{$record_meta['receiving']}}</td>
                            <td>{{$record_meta['manufactured']-$record_meta['receiving']}}</td>
                            <td>
{{--                                <a href="{{$url.'/'.$record->id.'/edit'}}" class=" "><span class="fa fa-edit" ></span></a>--}}
                                <a href="javascript:" onclick="openFullWindowLink('{{$url.'/'.$record->id}}')" class="text-success "><span class="fa fa-print" ></span></a>
                                <a href="javascript:" data-href="{{$url.'/'.$record->id}}" class="text-danger delete_a_record"><span class="fa fa-trash" ></span></a>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
                <tfoot>
                <tr>
                    <th>Total</th>
                    <th></th>
                    <th></th>
                    <th>{{number_format($output,2)}}</th>
                    <th>{{number_format($receiving,2)}}</th>
                    <th>{{number_format($output-$receiving,2)}}</th>
                    <th></th>
                </tr>
                </tfoot>
            </table>
        </div>
        {{$records->links()}}
    @endcomponent
</section>

@stop
@section('javascript')

@endsection
