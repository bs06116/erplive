<?php
return [
    'outsource_manufacturing_module' => 'Out Source Manufacturing Module',
    'stock_issuance_list' => 'Stock Issuance List',
    'stock_receiving_list' => 'Stock Receiving List',
];
