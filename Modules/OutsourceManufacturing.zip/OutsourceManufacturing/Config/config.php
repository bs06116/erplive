<?php

return [
    'name' => 'OutsourceManufacturing',
    'module_version' => '1.0',
    'pid' => 11
];
