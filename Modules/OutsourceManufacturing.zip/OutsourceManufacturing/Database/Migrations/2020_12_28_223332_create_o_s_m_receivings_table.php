<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateOSMReceivingsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('o_s_m_receivings', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('o_s_m_issuance_id');
            $table->unsignedBigInteger('business_id');
            $table->dateTime('date_time')->nullable();
            $table->string('ref_no')->nullable();
            $table->decimal('wastage',12,4)->nullable();
            $table->text('remarks')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
//        Schema::dropIfExists('o_s_m_receivings');
    }
}
